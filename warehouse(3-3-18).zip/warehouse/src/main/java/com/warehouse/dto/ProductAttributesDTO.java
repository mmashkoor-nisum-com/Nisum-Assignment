package com.warehouse.dto;

public class ProductAttributesDTO {
	
	private String productName;
	private String productSize;
	
	public ProductAttributesDTO() {
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductSize() {
		return productSize;
	}

	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}
	
}
